// CMPT 225 - Lab 08
// Created by Jocelyn Minns
// Do not repost

#include "SkipList.h"
#include <cstdlib>
#include <ctime>
#include <climits>

SkipList::SkipList()
{
    head = new Node{INT_MIN, nullptr, nullptr, nullptr, nullptr};
    head->next = new Node{INT_MAX, nullptr, head, nullptr, nullptr};
    height = 1;

    std::srand(std::time(0));
}

SkipList::~SkipList()
{
    while (head != nullptr)
    {
        Node *row = head;
        head = head->below;
        while (row)
        {
            Node *temp = row;
            row = row->next;
            delete temp;
        }
    }
}

bool SkipList::coinFlip()
{
    return rand() % 2 == 0;
}

Node *SkipList::skipSearch(int key)
{
    Node *p = head;
    while (p->below != nullptr)
    {
        p = p->below;
        while (key >= p->next->key)
            p = p->next;
    }
    return p;
}

bool SkipList::search(int key)
{
    return skipSearch(key)->key == key;
}

Node *SkipList::insertAfterAbove(Node *prev, Node *below, int key)
{
    Node *p = new Node{key, nullptr, nullptr, nullptr, nullptr};
    if (prev != nullptr)
    {
        p->prev = prev;
        p->next = prev->next;
        prev->next = p;
        if (p->next = nullptr)
        {
            p->next->prev = p;
        }
    }
    if (below != nullptr)
    {
        p->below = below;
        below->above = p;
    }
    return p;
}

void SkipList::insert(int key)
{
    Node *p = skipSearch(key);
    Node *q = nullptr;
    int level = 0;

    do
    {
        level++;
        if (level >= height)
        {
            height++;
            Node *t = head->next;
            head = insertAfterAbove(nullptr, head, INT_MIN);
            insertAfterAbove(head, t, INT_MAX);
        }
        q = insertAfterAbove(p, q, key);
        while (p->above == nullptr)
        {
            p = p->prev;
        }
        p = p->above;
    } while (coinFlip());
}

void SkipList::print()
{
    Node *row = head; // Start at the top level

    // Traverse each level top-down
    while (row != nullptr)
    {
        Node *curr = row->next; // skip INT_MIN (left sentinel)
        while (curr->next != nullptr)
        { // stop before right sentinel
            std::cout << curr->key << " ";
            curr = curr->next;
        }
        std::cout << std::endl;
        row = row->below;
    }
}
