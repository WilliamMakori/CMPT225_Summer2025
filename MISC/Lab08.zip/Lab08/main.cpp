// CMPT 225 - Lab 08
// Created by Jocelyn Minns
// Do not repost

#include "SkipList.h"

int main()
{
    SkipList list;
    list.insert(500);
    for (int i = 0; i < 9; i++)
    {
        list.insert(rand() % 1000);
    }

    std::cout << "Current list:" << std::endl;
    list.print();

    if (list.search(500))
        std::cout << "item 500 is found" << std::endl;

    if (!list.search(1001))
        std::cout << "item 1001 is not found" << std::endl;

    return 0;
}
