// CMPT 225 - Lab 08
// Created by Jocelyn Minns
// Do not repost

#ifndef SKIPLIST_HPP
#define SKIPLIST_HPP

#include <iostream>

struct Node {
    int key;
    Node* next;
    Node* prev;
    Node* above;
    Node* below;
};

class SkipList {
private:
    Node* head; // top-left head
    int height;

    bool coinFlip();  // Random coin flip
    Node* skipSearch(int key);
    Node* insertAfterAbove(Node* prev, Node* below, int key);

public:
    SkipList();
    bool search(int key);
    void insert(int key);
    void print(); // for debugging

    // should have all of big 3
    // but omitted for space
    ~SkipList(); 
};

#endif
