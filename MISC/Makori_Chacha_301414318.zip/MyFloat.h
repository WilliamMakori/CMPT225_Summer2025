//
//  MyFloat.h
//  Assignment 01 CMPT225
//
//  Created by Makori Chacha on 2025-05-26.
//
#ifndef MYFLOAT_HPP
#define MYFLOAT_HPP

#include <string>
#include <iostream>
using namespace std;
class MyFloat{
public:
    // Constructors
    MyFloat(); // Default
    
    MyFloat(const std::string& input);
    
    //Takes a string as an input
    
    
    // YOUR CODE HERE
    // Big 3
    // the big 3 functions are
    
    // A destructor
    // Just frees up the memory taken up by the short arrays
    
    ~MyFloat();
    
    //  A copy constructor
    
    MyFloat(const MyFloat& other);
    
    // Assignment operator
    
    MyFloat& operator = (const MyFloat& other);
    
    // Addition operator
    MyFloat operator+(const MyFloat& other) const; //Addition operator
    
    // Comparison operators
    bool operator==(const MyFloat& other) const; // Comparison equal operator
    bool operator!=(const MyFloat& other) const; // Comparison not equal operator
    
    // Friend functions (for input and output)
    friend std::ostream& operator<<(std::ostream& os, const MyFloat& f); // output operator
    friend std::istream& operator>>(std::istream& is, MyFloat& f); // input operator, need to implement this
    
    
private:
    // Data members
    short* integer;
    int integerLen; // The default constructor puts this at 1
    
    short* fractional;
    int fractionalLen; // The default constructor puts this at 1
    
    // helpers functions (YOU CAN ADD MORE HELPERS HERE)
    bool isValidNumber(const std::string& str) const;
    void parseFromString(const std::string& input);
    
    void normalize(); // Normalizes the numbers so that the comparisons can be done better
    // Removes leading and trailing zeros where they aren't necessary
    
    
    
};

#endif // MYFLOAT_HPP



