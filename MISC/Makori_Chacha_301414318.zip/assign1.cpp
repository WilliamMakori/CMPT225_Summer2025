#include "MyFloat.h"
#include <iostream>
#include <stdexcept>

using namespace std;

// Function for exception handling testing.

void run_exception_tests() {
    cout << "Exception Test 01: Empty string" << endl;
    try {
        MyFloat bad1("");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }

    cout << "Exception Test 02: Invalid characters" << endl;
    try {
        MyFloat bad2("12.3a4");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }

    cout << "Exception Test 03: Multiple decimal points" << endl;
    try {
        MyFloat bad3("1.2.3");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }

    cout << "Exception Test 04: Just a minus sign" << endl;
    try {
        MyFloat bad4("-");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }

    cout << "Exception Test 05: Leading decimal with no digits before" << endl;
    try {
        MyFloat bad5(".123");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }

    cout << "Exception Test 06: Trailing decimal with no digits after" << endl;
    try {
        MyFloat bad6("123.");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }

    cout << "Exception Test 07: Multiple signs" << endl;
    try {
        MyFloat bad7("++1.23");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }

    cout << "Exception Test 08: Spaces in number" << endl;
    try {
        MyFloat bad8("1 000.00");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }

    cout << "Exception Test 09: Null character in string" << endl;
    try {
        MyFloat bad9("123\0.45");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }

    cout << "Exception Test 10: Extremely long string of garbage" << endl;
    try {
        MyFloat bad10("this_is_not_a_number_at_all");
    } catch (const std::exception& e) {
        cout << "Caught expected exception: " << e.what() << endl;
    }
}

int main() {
  // Testing the code
    
    cout <<"Test 01"<< endl;
    
    MyFloat a("1.1");
    MyFloat b("2.2");
    MyFloat c = a + b;
    std::cout << a << " + " << b << " = " << c << " (Expected: 3.3)" << std::endl;
    MyFloat d("0.0");
    MyFloat e("5.0");
    std::cout << d << " + " << e << " = " << (d + e) << " (Expected: 5.0)" << std::endl;
    cout <<"Test 02"<< endl;
    MyFloat f("0.999");
    MyFloat g("0.001");
    std::cout << f << " + " << g << " = " << (f + g) << " (Expected: 1.000)" << std::endl;
    
    cout <<"Test 03"<< endl;
    MyFloat h("12345678901234567890.123456789");
    MyFloat i("0.000000001");
    std::cout << h << " + " << i << " = " << (h + i) << " (Expected: 12345678901234567890.123456790)" << std::endl;
    cout <<"Test 04"<< endl;
    MyFloat j("1.00001");
    MyFloat k("2.1");
    std::cout << j << " + " << k << " = " << (j + k) << " (Expected: 3.10001)" << std::endl;
    
    cout <<"Test 05"<< endl;
    MyFloat m1("0.123");
    MyFloat m2("456.789");
    std::cout << m1 + m2 << " == " << m2 + m1 << " (Expected: 456.912)" << std::endl;
    
    cout <<"Test 06"<< endl;
    MyFloat x("1.5000");
    MyFloat y("1.5");
    std::cout << "Are they equal? " << (x == y ? "Yes" : "No") << " (Expected: Yes)" << std::endl;
    
    cout <<"Test 07"<< endl;
    MyFloat z1("000012.3400");
    MyFloat z2("12.34");
    std::cout << "Are they equal? " << (z1 == z2 ? "Yes" : "No") << " (Expected: Yes)" << std::endl;
    cout <<"Test 08"<< endl;
    MyFloat int1("50");
    MyFloat int2("25");
    std::cout << int1 << " + " << int2 << " = " << (int1 + int2) << " (Expected: 75)" << std::endl;
    cout <<"Test 09"<< endl;
    MyFloat nines("999.999");
    MyFloat one("0.001");
    std::cout << nines << " + " << one << " = " << (nines + one) << " (Expected: 1000.000)" << std::endl;
    
    cout <<"Test 10"<< endl;
    MyFloat tiny1("0.00000000000001");
    MyFloat tiny2("0.00000000000002");
    std::cout << tiny1 << " + " << tiny2 << " = " << (tiny1 + tiny2) << " (Expected: 0.00000000000003)" << std::endl;
    
    
    run_exception_tests();
    return 0;
}
